from django.db import models

# Create your models here.
class project(models.Model):
    name =models.CharField(max_length=32,default="")
    proid = models.IntegerField(max_length=15)
    teachername = models.CharField(max_length=32,default="")

class user(models.Model):
    username = models.CharField(max_length=32,default="")
    password  = models.CharField(max_length=32,default="")
    phonenum  = models.CharField(max_length=32,default="")
    issuperuser = models.BooleanField(blank=False)
    number = models.CharField(max_length=32,default="")
