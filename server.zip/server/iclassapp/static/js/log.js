function checkForm() {
    var nametip = checkUserName();
    var passtip = checkPassword();
    var conpasstip = ConfirmPassword();
    var phonetip = checkPhone();
    return nametip && passtip && conpasstip && phonetip;
}
//验证用户名   
function checkUserName() {
    var username = document.getElementById('userName');
    var errname = document.getElementById('nameErr');
    var pattern = /^\w{5,}$/; //用户名格式正则表达式：用户名要至少五位 
    if (username.value.length == 0) {
        errname.innerHTML = "用户名不能为空";
        errname.className = "error";
        return false;
    }
    if (!pattern.test(username.value)) {
        errname.innerHTML = "用户名不合规范";
        errname.className = "error";
        return false;
    } else {
        errname.innerHTML = "√";
        errname.className = "success";
        return true;
    }
}
//验证密码   
function checkPassword() {
    var userpasswd = document.getElementById('userPasword');
    var errPasswd = document.getElementById('passwordErr');
    var pattern = /^\w{4,20}$/; //密码要在4-20位 
    if (userpasswd.value.length == 0) {
        errPasswd.innerHTML = "密码不能为空";
        errPasswd.className = "error";
        return false;
    }
    if (!pattern.test(userpasswd.value)) {
        errPasswd.innerHTML = "密码不合规范";
        errPasswd.className = "error";
        return false;
    } else {
        errPasswd.innerHTML = "√"
        errPasswd.className = "success";
        return true;
    }
}