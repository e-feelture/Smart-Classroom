function fn() {
    let $sel1 = $("#sel1").val();
    let $sel2 = $("#sel2");
    switch ($sel1) {
        case "水文水资源学院":
            $sel2.html(`<option>生态水利</option>
                        <option>水文学及水资源</option>
                        <option>城市水务</option>`);
            break;
        case "水利水电学院":
            $sel2.html(`<option>水工结构工程</option>
                        <option>水力学及河流动力学</option>
                        <option>水利水电工程</option>
                        <option>防灾减灾工程及防护工程</option>
                        <option>水灾害与水安全</option>
                        <option>水利水电建设工程管理</option>
                        <option>农业水土工程</option>
                        <option>农业生物环境与能源工程</option>
                        <option>土壤学</option>`);
            break;
        case "港口海岸与近海工程学院":
            $sel2.html(`<option>港口、海岸及近海工程</option>
                        <option>海岸带资源与环境</option>`);
            break;
        case "土木与交通学院":
            $sel2.html(`<option>土木工程</option>
                        <option>交通运输工程</option>`);
            break;

        case "环境学院":
            $sel2.html(`<option value="环境学院">环境科学与工程</option>
                        <option value="环境学院">市政工程</option>`);
            break;
        case "力学与材料学院":
            $sel2.html(`<option value="力学与材料学院">工程力学</option>
                        <option value="力学与材料学院">材料科学与工程</option>`);
            break;
        case "地球科学与工程学院":
            $sel2.html(`<option value="地球科学与工程学院">地质资源与地质工程</option>
                        <option value="地球科学与工程学院">测绘科学与技术</option>
                        <option value="地球科学与工程学院">地理学</option>
                        <option value="地球科学与工程学院">地质学</option>`);
            break;
        case "农业工程学院":
            $sel2.html(`<option value="农业工程学院">农业工程</option>`);
            break;
        case "海洋学院":
            $sel2.html(`<option value="海洋学院">海洋科学</option>`);
            break;
        case "企业管理学院":
            $sel2.html(`<option value="企业管理学院">工商管理­专业</option>
                        <option value="企业管理学院">信息管理与信息系统专业</option>
                        <option value="企业管理学院">国际经济与贸易专业</option>
                        <option value="企业管理学院">会计学专业</option>`);
            break;
        case "理学院":
            $sel2.html(`<option value="理学院">数学与应用数学</option>
                        <option value="理学院">应用物理</option>
                        <option value="理学院">信息与计算科学</option>`);
            break;
        case "公共管理学院":
            $sel2.html(`<option value="公共管理学院">社会学</option>
                        <option value="公共管理学院">教育学</option>
                        <option value="公共管理学院">心理学</option>
                        <option value="公共管理学院">新闻传播学</option>
                        <option value="公共管理学院">管理科学与工程</option>
                        <option value="公共管理学院">公共管理</option>`);
            break;
        case "马克思主义学院":
            $sel2.html(`<option value="马克思主义学院">马克思主义学</option>`);
            break;
        case "机电工程学院":
            $sel2.html(`<option value="机电工程学院">机械工程</option>
                        <option value="机电工程学院">能源与动力工程</option>
                        <option value="机电工程学院">金属材料工程</option>
                        <option value="机电工程学院">工业设计</option>`);
            break;
        case "物联网工程学院":
            $sel2.html(`<option value="物联网工程学院">电子科学与技术专业</option>
                        <option value="物联网工程学院">计算机科学与技术专业</option>
                        <option value="物联网工程学院">物联网工程专业</option>
                        <option value="物联网工程学院">自动化专业</option>
                        <option value="物联网工程学院">通信工程专业</option>`);
            break;
        case "计算机与信息学院":
            $sel2.html(`<option value="计算机与信息学院">计算机科学与技术</option>
                        <option value="计算机与信息学院">通信工程</option>
                        <option value="计算机与信息学院">电子信息工程</option>`);
            break;
        case "能源与电气学院":
            $sel2.html(`<option value="能源与电气学院">电气工程</option>
                        <option value="能源与电气学院">控制科学与工程</option>
                        <option value="能源与电气学院">仪器科学与技术</option>
                        <option value="能源与电气学院">动力工程与工程物理</option>`);
            break;
        case "商学院":
            $sel2.html(`<option value="商学院">理论经济学</option>
                        <option value="商学院">应用经济学</option>
                        <option value="商学院">工商管理</option>
                        <option value="商学院">管理科学与工程</option>`);
            break;
        case "法学院":
            $sel2.html(`<option value="法学院">法学</option>`);
            break;
        case "外国语学院":
            $sel2.html(`<option value="外国语学院">英语专业</option>`);
            break;
        default:
            alert("error");
    }
};

let $name = $("#name");
let $num = $("#num");
let $info1 = $("#info1");
let $info2 = $("#info2");
$info1.css('display', 'none');
$info2.css('display', 'none');
let $btn = $("#button");
let reg = /^\d{1,}$/;

$name.on('blur', function() {
    if ($name.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`姓名不能为空！`);
    } else {
        $info1.css('display', 'none');
    }
})

$name.on('input', function() {
    if ($name.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`姓名不能为空！`);
    } else {
        $info1.css('display', 'none');
    }
})

$num.on('blur', function() {
    if ($num.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`学号不能为空！`);
    } else if (!reg.test($num.val())) {
        $info2.css('display', 'block');
        $info2.text(`学号不符合规范！`);
    } else {
        $info2.css('display', 'none');
    }
})

$num.on('input', function() {
    if ($num.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`学号不能为空！`);
    } else if (!reg.test($num.val())) {
        $info2.css('display', 'block');
        $info2.text(`学号不符合规范！`);
    } else {
        $info2.css('display', 'none');
    }
})

$btn.click(() => {
    let name = $("#name");
    let num = $("#num")
    if (!name.val().length == 0 && !num.val().length == 0 && reg.test(num.val())) {
        window.location.href = "success.html";
    }
    if (name.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`姓名不能为空！`);
    }
    if (num.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`学号不能为空！`);
    }
})