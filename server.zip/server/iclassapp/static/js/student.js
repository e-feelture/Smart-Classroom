$(document).ready(function() {
    let obj = new Object();
    obj = GetRequest();
    let { course, id, weeks, term } = obj;

    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }


    var chart = {
        type: 'bar'
    };
    var title = {
        text: `${course}    课程ID：${id}`
    };
    var subtitle = {
        text: `   第${weeks}周 ${term}`
    };
    var xAxis = {
        categories: ['东邪', '西毒', '南帝', '北丐', '中神通'],
        title: {
            text: "学生姓名",
            align: 'high'
        }
    };
    var yAxis = {
        min: 0,
        title: {
            text: '课堂状态比例(%)',
            align: 'high'
        },
        labels: {
            overflow: 'justify'
        }
    };
    var tooltip = {
        valueSuffix: '%'
    };
    var plotOptions = {
        bar: {
            dataLabels: {
                enabled: true
            }
        },
        series: {
            stacking: 'normal'
        }
    };
    var legend = {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 100,
        floating: true,
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
        shadow: true
    };
    var credits = {
        enabled: false
    };

    var series = [{
        name: '专注',
        data: [50, 60, 55, 65, 72, 50, 60, 55, 65, 72, 50, 60, 55, 65, 72, 50, 60, 55, 65, 72, 50, 60, 55, 65, 72, 50, 60, 55, 65, 72, 50, 60, 55, 65, 72, 50, 60, 55, 65, 72]
    }, {
        name: '发呆',
        data: [10, 5, 5, 10, 5, 10, 5, 5, 10, 5, 10, 5, 5, 10, 5, 10, 5, 5, 10, 5, 10, 5, 5, 10, 5, 10, 5, 5, 10, 5, 10, 5, 5, 10, 5, 10, 5, 5, 10, 5]
    }, {
        name: '玩手机',
        data: [15, 20, 20, 15, 3, 15, 20, 20, 15, 3, 15, 20, 20, 15, 3, 15, 20, 20, 15, 3, 15, 20, 20, 15, 3, 15, 20, 20, 15, 3, 15, 20, 20, 15, 3, 15, 20, 20, 15, 3]
    }, {
        name: '睡觉',
        data: [10, 5, 10, 5, 0, 10, 5, 10, 5, 0, 10, 5, 10, 5, 0, 10, 5, 10, 5, 0, 10, 5, 10, 5, 0, 10, 5, 10, 5, 0, 10, 5, 10, 5, 0, 10, 5, 10, 5, 0]
    }, {
        name: '聊天',
        data: [10, 5, 5, 0, 10, 10, 5, 5, 0, 10, 10, 5, 5, 0, 10, 10, 5, 5, 0, 10, 10, 5, 5, 0, 10, 10, 5, 5, 0, 10, 10, 5, 5, 0, 10, 10, 5, 5, 0, 10]
    }, {
        name: '回答问题',
        data: [5, 5, 5, 5, 10, 5, 5, 5, 5, 10, 5, 5, 5, 5, 10, 5, 5, 5, 5, 10, 5, 5, 5, 5, 10, 5, 5, 5, 5, 10, 5, 5, 5, 5, 10, 5, 5, 5, 5, 10]
    }];

    var json = {};
    json.chart = chart;
    json.title = title;
    json.subtitle = subtitle;
    json.tooltip = tooltip;
    json.xAxis = xAxis;
    json.yAxis = yAxis;
    json.series = series;
    json.plotOptions = plotOptions;
    json.legend = legend;
    json.credits = credits;
    $('#picture').highcharts(json);


});