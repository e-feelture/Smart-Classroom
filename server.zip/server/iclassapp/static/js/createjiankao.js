let $usr = $("#usr");
let $id = $("#id");
let $teacher = $("#teacher");
let $num = $("#number");
let $info1 = $("#info1");
let $info2 = $("#info2");
let $info3 = $("#info3");
let $info4 = $("#info4");
$info1.css('display', 'none');
$info2.css('display', 'none');
$info3.css('display', 'none');
$info4.css('display', 'none');
let reg = /^\d{1,}$/;
$usr.on('blur', function() {
    if ($usr.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`课程名称不能为空！`);
    } else {
        $info1.css('display', 'none');
    }
})

$usr.on('input', function() {
    if ($usr.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`课程名称不能为空！`);
    } else {
        $info1.css('display', 'none');
    }
})

$id.on('blur', function() {
    if ($id.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`ID号不能为空！`);
    } else if (!reg.test($id.val())) {
        $info2.css('display', 'block');
        $info2.text(`ID号不符合规范！`);
    } else {
        $info2.css('display', 'none');
    }
})

$id.on('input', function() {
    if ($id.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`ID号不能为空！`);
    } else if (!reg.test($id.val())) {
        $info2.css('display', 'block');
        $info2.text(`ID号不符合规范！`);
    } else {
        $info2.css('display', 'none');
    }
})

$teacher.on('blur', function() {
    if ($teacher.val().length == 0) {
        $info3.css('display', 'block');
        $info3.text(`教师姓名不能为空！`);
    } else {
        $info3.css('display', 'none');
    }
})

$teacher.on('input', function() {
    if ($teacher.val().length == 0) {
        $info3.css('display', 'block');
        $info3.text(`教师姓名不能为空！`);
    } else {
        $info3.css('display', 'none');
    }
})

$num.on('blur', function() {
    if ($num.val().length == 0) {
        $info4.css('display', 'block');
        $info4.text(`教室号码不能为空！`);
    } else if (!reg.test($num.val())) {
        $info4.css('display', 'block');
        $info4.text(`教室号码不符合规范！`);
    } else {
        $info4.css('display', 'none');
    }
})

$num.on('input', function() {
    if ($num.val().length == 0) {
        $info4.css('display', 'block');
        $info4.text(`教室号码不能为空！`);
    } else if (!reg.test($num.val())) {
        $info4.css('display', 'block');
        $info4.text(`教室号码不符合规范！`);
    } else {
        $info4.css('display', 'none');
    }
})

let $btn = $("#button");
$btn.click(() => {
    let usr = $("#usr");
    let id = $("#id");
    let teacher = $("#teacher");
    let num = $("#number");
    let val = $("#sel1 option:selected").text();
    if (!usr.val().length == 0 && !id.val().length == 0 && !teacher.val().length == 0 && !num.val().length == 0 && reg.test(id.val()) && reg.test(num.val())) {
        window.location.href = "jiankao.html?number=" + num.val() + "&position=" + encodeURI(val) + "&course=" + encodeURI(usr) + "&teacher=" + encodeURI(teacher);
    }
    if (usr.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`课程名称不能为空！`);
    }
    if (id.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`ID号不能为空！`);
    }
    if (teacher.val().length == 0) {
        $info3.css('display', 'block');
        $info3.text(`教师姓名不能为空！`);
    }
    if (num.val().length == 0) {
        $info4.css('display', 'block');
        $info4.text(`教室号不能为空！`);
    }
})