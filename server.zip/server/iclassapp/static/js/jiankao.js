let $info = $("#info");
let obj = new Object();
obj = GetRequest();
console.log(obj)

let { number, position, course, teacher } = obj;
$info.html(`地点：${position} ${number} 智能监考中
            <br>考试科目：${course} 监考老师：${teacher}`)

function GetRequest() {
    var url = location.search; //获取url中"?"符后的字串
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}