from django.shortcuts import render
from datetime import datetime
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseRedirect, StreamingHttpResponse
from django.contrib import auth
import os
import xlwt
import random
from iclassapp import models
from docx import Document
from django.core.mail import send_mail

# Create your views here.
def regist(request):
    if request.method == "POST":
        username = request.POST.get("username", None)
        password = request.POST.get("password", None)
        phone = request.POST.get("phone", None)
        number = request.POST.get("number", None)
        userinfo = models.user.objects.filter()
        for i in range(len(userinfo)):
            if userinfo[i].username == username:
                return render(request, "regist.html", {"error": "用户名已存在"})
        models.user.objects.create(username=username,issuperuser=False, password=password, phonenum=phone, number=number)
        user = User.objects.create_user(username, None, password)
        user.save()
        userlogin = auth.authenticate(username=username, password=password)
        auth.login(request, userlogin)
        return render(request,"success.html",{"isLogin":1,"username":username})
    return render(request,"regist.html")

def login(request):

    if request.method == "POST":
        username = request.POST.get("username", None)
        password = request.POST.get("password", None)
        user = auth.authenticate(username=username, password=password)
        if user is not None and user.is_active:
            auth.login(request, user)
            return render(request,"success.html",{"isLogin":1,"username":username})
        if user is None:
            errors = []
            errors.append("用户名或密码错误！")
            return render(request, "log.html", {'errors': errors})

    return render(request, "log.html")

def index(request):
    if request.user.is_authenticated:
        a = models.user.objects.get(username=request.user.username).username
        return render(request, "success.html",
                      {'isLogin': 1, 'username': a})
    else:
        return render(request, "success.html")

def logout(request):
    auth.logout(request)
    return render(request, 'success.html')