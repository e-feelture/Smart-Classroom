from django.apps import AppConfig


class IclassappConfig(AppConfig):
    name = 'iclassapp'
