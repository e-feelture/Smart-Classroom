let obj = new Object();
obj = GetRequest();
let { course, id, teacher } = obj;

function GetRequest() {
    var url = location.search; //获取url中"?"符后的字串
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}
let $display = $("#display");
let div = $("<div>");
div.html(`
    <p>课程：${course}</p> 
    <p>课程ID：${id}</p> 
    <p>任课教师：${teacher}</p> 
    <button id="button" class="btn btn-primary" style="margin-top:5px;width:150px;position:relative;left:72px">加入班级</button>
 `)
$display.append(div);
let $btn = $("#button");
$btn.click(() => {
    window.location.href = "information.html"
})