// let $usr = $("#usr");
// let $info = $("#info");
// $info.css('display', 'none');
// let reg = /^\d{1,}$/;
// $usr.on('blur', function() {
//     if ($usr.val().length == 0) {
//         $info.css('display', 'block');
//         $info.text(`ID号不能为空！`);
//     } else if (!reg.test($usr.val())) {
//         $info.css('display', 'block');
//         $info.text(`ID号不符合规范！`);
//     } else {
//         $info.css('display', 'none');
//     }
// })

// $usr.on('input', function() {
//     if ($usr.val().length == 0) {
//         $info.css('display', 'block');
//         $info.text(`ID号不能为空！`);
//     } else if (!reg.test($usr.val())) {
//         $info.css('display', 'block');
//         $info.text(`ID号不符合规范！`);
//     } else {
//         $info.css('display', 'none');
//     }
// })

let $btn = $("#button");
$btn.click(() => {
    let $val1 = $("#sel1 option:selected").text();
    let $val2 = $("#sel2 option:selected").text();
    window.location.href = "teacher.html?course=" + encodeURI($val1) + "&term=" + encodeURI($val2);

})