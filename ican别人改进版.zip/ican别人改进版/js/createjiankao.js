// let $usr = $("#usr");
let $id = $("#id");
// let $info1 = $("#info1");
let $info2 = $("#info2");
// $info1.css('display', 'none');
$info2.css('display', 'none');
// $usr.on('blur', function() {
//     if ($usr.val().length == 0) {
//         $info1.css('display', 'block');
//         $info1.text(`考试科目不能为空！`);
//     } else {
//         $info1.css('display', 'none');
//     }
// })

// $usr.on('input', function() {
//     if ($usr.val().length == 0) {
//         $info1.css('display', 'block');
//         $info1.text(`考试科目不能为空！`);
//     } else {
//         $info1.css('display', 'none');
//     }
// })

$id.on('blur', function() {
    if ($id.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`监考ID号不能为空！`);
    } else {
        $info2.css('display', 'none');
    }
})

$id.on('input', function() {
    if ($id.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`监考ID号不能为空！`);
    } else {
        $info2.css('display', 'none');
    }
})

let $btn = $("#button");
$btn.click(() => {
    // let usr = $("#usr");
    let id = $("#id");
    if (!id.val().length == 0) {
        window.location.href = "resultjk.html?id=" + encodeURI(id.val());
    }
    // if (usr.val().length == 0) {
    //     $info1.css('display', 'block');
    //     $info1.text(`考试科目不能为空！`);
    // }
    if (id.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`监考ID号不能为空！`);
    }

})