let obj = new Object();
obj = GetRequest();
let { id } = obj;

function GetRequest() {
    var url = location.search; //获取url中"?"符后的字串
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}
// console.log(course, id)
let $sel1 = $("#sel1");
$sel1.html(`
    <option>&nbsp;${id}</option>
`)

let $btn = $("#button");
$btn.click(() => {
    window.location.href = "jiankao.html?id=" + encodeURI(id);
})