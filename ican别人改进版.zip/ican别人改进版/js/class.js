$(function() {
    let obj = new Object();
    obj = GetRequest();
    let { course, term } = obj;

    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }

    $('#picture').highcharts({
        chart: {
            type: 'line'
        },
        title: {
            text: `${course}`
        },
        subtitle: {
            text: `时间：${term}`
        },
        ubtitle: {
            text: 'wy'
        },
        xAxis: {
            categories: ['第二周', '第三周', '第三周', '第四周', '第五周', '第六周', '第七周', '第八周', '第九周', '第十周', '第十一周', '第十二周', ]
        },
        yAxis: {
            title: {
                text: '专注度/%',
                align: 'high'
            }
        },
        tooltip: {
            enabled: true,
            formatter: function() {
                return '<b>' + this.series.name + '</b><br/>' + this.x + '时候的专注度为: ' + this.y + '%';
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        series: [{
            name: `课程号：100110320180101上课状态`,
            data: [70, 58, 95, 75, 84, 65, 52, 85, 55, 80, 79, 96]
        }, {
            name: `课程号：100110320180102上课状态`,
            data: [65, 60, 80, 90, 80, 65, 55, 88, 51, 70, 75, 90]
        }, {
            name: `课程号：100110320180103上课状态`,
            data: [65, 60, 80, 90, 80, 65, 55, 88, 51, 70, 75, 90]
        }]
    });
});