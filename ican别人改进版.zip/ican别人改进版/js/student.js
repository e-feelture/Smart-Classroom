$(document).ready(function() {
    let obj = new Object();
    obj = GetRequest();
    let { course, id, weeks, term } = obj;

    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }


    var chart = {
        type: 'bar'
    };
    var title = {
        text: `${course}    课程ID：${id}`
    };
    var subtitle = {
        text: `   第${weeks}周 ${term}`
    };
    var xAxis = {
        categories: ['王家琛', '路西', '蔡玉云', '王雨格', '刘欣欣', '刘立文', '张乐民', '李想', '张以撒', '蒋方舟', '吴亦凡', '吴岳年', '魏建发', '赵惟依', '刘雨燕','刘家琛', '路一西', '张玉云', '王银格', '刘欣亚', '刘文', '张乐天', '王想', '张撒', '周方舟', '刘凡', '吴年', '雷建发', '赵一依', '张浩天'],
        title: {
            text: "学生姓名",
            align: 'high'
        }
    };
    var yAxis = {
        min: 0,
        max: 10.5,
        title: {
            text: '课堂状态次数分布',
            align: 'high'
        },
        labels: {
            overflow: 'justify'
        }
    };
    var tooltip = {
        valueSuffix: '次'
    };
    var plotOptions = {
        bar: {
            dataLabels: {
                enabled: true
            }
        },
        series: {
            stacking: 'normal'
        }
    };
    var legend = {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 100,
        floating: true,
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
        shadow: true
    };
    var credits = {
        enabled: false
    };

    var series = [{
        name: '专注',
        data: [6, 7, 6, 8, 7, 5, 6, 5, 4, 7, 5, 6, 5, 3, 7, 9, 6, 5, 6, 2, 5, 6, 5, 6, 7, 5, 6, 5, 4, 8, 8, 6, 7, 9, 8, 7, 6, 7, 6, 8]
    }, {
        name: '玩手机',
        data: [2, 1, 2, 0, 3, 1, 2, 2, 5, 3, 5, 2, 2, 6, 3, 0, 0, 0, 0, 7, 1, 2, 2, 1, 3, 5, 2, 2, 5, 0, 1, 2, 2, 1, 2, 1, 2, 2, 1, 0]
    }, {
        name: '睡觉',
        data: [1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 2, 5, 3, 0, 4, 2, 1, 2, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 2, 2]
    }, {
        name: '回答问题',
        data: [1, 1, 2, 2, 0, 3, 1, 2, 0, 0, 0, 2, 2, 0, 0, 1, 2, 0, 1, 1, 0, 0, 2, 1, 0, 0, 1, 2, 0, 2, 1, 1, 0, 0, 0, 1, 2, 0, 1, 0]
    }];

    var json = {};
    json.chart = chart;
    json.title = title;
    json.subtitle = subtitle;
    json.tooltip = tooltip;
    json.xAxis = xAxis;
    json.yAxis = yAxis;
    json.series = series;
    json.plotOptions = plotOptions;
    json.legend = legend;
    json.credits = credits;
    $('#picture').highcharts(json);


});