$(document).ready(function() {
    let obj = new Object();
    obj = GetRequest();
    let { course, term } = obj;

    function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }

    var chart = {
        type: 'bar'
    };
    var title = {
        text: `教师课堂受欢迎程度`
    };
    var subtitle = {
        text: `课程：${course}  时间：${term}`
    };
    var xAxis = {
        categories: ['张建民', '王艳芳', '周震南', '李旭杰', '李思雨'],
        title: {
            text: "教师姓名",
            align: 'high'
        }
    };
    var yAxis = {
        min: 0,
        title: {
            text: '%',
            align: 'high'
        },
        labels: {
            overflow: 'justify'
        }
    };
    var tooltip = {
        valueSuffix: '%'
    };
    var plotOptions = {
        bar: {
            dataLabels: {
                enabled: true
            }
        }
    };
    var legend = {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 100,
        floating: true,
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
        shadow: true
    };
    var credits = {
        enabled: false
    };

    var series = [{
        name: '学生专注度',
        data: [70, 80, 85, 65, 90]
    }];

    var json = {};
    json.chart = chart;
    json.title = title;
    json.subtitle = subtitle;
    json.tooltip = tooltip;
    json.xAxis = xAxis;
    json.yAxis = yAxis;
    json.series = series;
    json.plotOptions = plotOptions;
    json.legend = legend;
    json.credits = credits;
    $('#picture').highcharts(json);

});