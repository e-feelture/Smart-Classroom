let $usr = $("#usr");
let $info = $("#info");
$info.css('display', 'none');
let reg = /^\d{1,}$/;
$usr.on('blur', function() {
    if ($usr.val().length == 0) {
        $info.css('display', 'block');
        $info.text(`ID号不能为空！`);
    } else if (!reg.test($usr.val())) {
        $info.css('display', 'block');
        $info.text(`ID号不符合规范！`);
    } else {
        $info.css('display', 'none');
    }
})

$usr.on('input', function() {
    if ($usr.val().length == 0) {
        $info.css('display', 'block');
        $info.text(`ID号不能为空！`);
    } else if (!reg.test($usr.val())) {
        $info.css('display', 'block');
        $info.text(`ID号不符合规范！`);
    } else {
        $info.css('display', 'none');
    }
})

let $btn = $("#button");
$btn.click(() => {
    let usr = $("#usr");
    if (!usr.val().length == 0 && reg.test($usr.val())) {
        window.location.href = "success.html";
    } else if ($usr.val().length == 0) {
        $info.css('display', 'block');
        $info.text(`ID号不能为空！`);
    } else {
        $info.css('display', 'block');
        $info.text(`ID号不符合规范！`);
    }
})