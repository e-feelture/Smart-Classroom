let $btn = $("#button");
let $weeks = $("#weeks");
let $id = $("#id");
let reg = /^\d{1,}$/;
let $info1 = $("#info1")
$info1.css('display', 'none');
let $info2 = $("#info2");
$info2.css('display', 'none');
$id.on('blur', function() {
    if ($id.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`ID号不能为空！`);
    } else if (!reg.test($id.val())) {
        $info1.css('display', 'block');
        $info1.text(`ID号不符合规范！`);
    } else {
        $info1.text(``);
        $info1.css('display', 'none')
    }

})

$id.on('input', function() {
    if ($id.val().length == 0) {
        $info1.css('display', 'block');
        $info1.text(`ID号不能为空！`);
    } else if (!reg.test($id.val())) {
        $info1.css('display', 'block');
        $info1.text(`ID号不符合规范！`);
    } else {
        $info1.css('display', 'none');
    }
})

$weeks.on('blur', function() {
    if ($weeks.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`周数不能为空！`);
    } else if (!reg.test($weeks.val())) {
        $info2.css('display', 'block');
        $info2.text(`周数不符合规范！`);
    } else {
        $info2.css('display', 'none');
    }

})

$weeks.on('input', function() {
    if ($weeks.val().length == 0) {
        $info2.css('display', 'block');
        $info2.text(`周数不能为空！`);
    } else if (!reg.test($weeks.val())) {
        $info2.css('display', 'block');
        $info2.text(`周数不符合规范！`);
    } else {
        $info2.css('display', 'none');
    }
})
$btn.click(function() {
    let $val1 = $("#sel1 option:selected").text();
    let $weeks = $("#weeks").val();
    let $id = $("#id").val();
    let $val2 = $("#sel2 option:selected").text();
    if (!$weeks.length == 0 && !$id.length == 0 && reg.test($weeks) && reg.test($id)) {
        window.location.href = "student.html?course=" + encodeURI($val1) + "&id=" + $id + "&weeks=" + $weeks + "&term=" + encodeURI($val2);
    }
    if ($id.length == 0) {
        $info1.css('display', 'block');
        $info1.text(`ID号不能为空！`);

    }
    if ($weeks.length == 0) {
        $info2.css('display', 'block');
        $info2.text(`周数不能为空！`);
    }
})